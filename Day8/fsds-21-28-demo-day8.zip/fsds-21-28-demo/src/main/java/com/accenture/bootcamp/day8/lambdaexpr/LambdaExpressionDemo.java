package com.accenture.bootcamp.day8.lambdaexpr;

import com.accenture.bootcamp.day6.Employee;
import com.accenture.bootcamp.day7.interfaces.IBusinessStrategy;
import com.accenture.bootcamp.day7.interfaces.IReport;

/*
 * Java 8 added feature
 * lambda expression = implementing functional interfaces
 * functional interface = interface with only one abstract method
 * -3 ways to implement an interface
 * 1. implements keyword
 * 2. anonymous inner class
 * 3. lambda expression (functional interface only)
 * syntax: (args) -> { body }
 */

public class LambdaExpressionDemo {

	public static void main(String[] args) {
		
		//anonymous inner class
		IBusinessStrategy ibs = new IBusinessStrategy() {
			
			@Override
			public void displayPromotionals() {
				System.out.println("Free coffee for first 10 clients.");
				
			}
		};
		
		ibs.displayPromotionals();
		
		//lambda expression
		IBusinessStrategy ibs2 = () -> { 
			System.out.println("Free milk tea for first 10 clients."); 
		};
		
		ibs2.displayPromotionals();
		
		Employee emp1 = new Employee();
		
		IReport ir = (income) -> {
			System.out.println("Income for April 2021: " + income);
		};
		
		ir.generateReport(100000);
		
	}

}
