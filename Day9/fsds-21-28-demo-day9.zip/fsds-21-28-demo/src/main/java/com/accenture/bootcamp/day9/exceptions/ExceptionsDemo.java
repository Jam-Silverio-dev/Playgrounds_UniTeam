package com.accenture.bootcamp.day9.exceptions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

/*
 * exceptions = recoverable exceptional events that arise during execution
 * handle exceptions = responsibility
 * error handling = no such thing
 * errors = irrecoverable, no need to handle
 * 
 * 2 types of exceptions
 * 1. checked = compile-time
 * 2. unchecked = run-time
 * 
 * 
 */

public class ExceptionsDemo {

	public static void main(String[] args) throws Exception {
		
		//Checked exception
		File file = new File("C:/sample.txt");
		try {
			FileReader fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			System.out.println("File not Found.");
		}
		
		try {
			throwException();
		} catch (Exception e) {
			System.out.println("Exception caught...");
		}
		
		//unchecked exception
		int[] array = {1,2,3,4};
		System.out.println(array[4]);
		

	}
	
	public static void throwException() throws Exception {
		throw new Exception();
	}

}
