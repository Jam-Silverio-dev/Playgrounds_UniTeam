package com.accenture.bootcamp.day8.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/*
 * Collections Framework
 * Set = collection of elements that are unique, no duplicates allowed
 * 	   = unordered collection, focus on membership
 *     = HashSet, TreeSet (sorted), EnumSet
 * List = ordered collection, allow duplicates, no sorted list
 */

public class CollectionsDemo {

	public static void main(String[] args) {
		
		//Set<String> actorSet = new HashSet<String>();
		Set<String> actorSet = new TreeSet<String>();
		
		actorSet.add("Tom Cruise");
		actorSet.add("Brad Pitt");
		actorSet.add("Al Pacino");
		actorSet.add("Chris Hemsworth");
		actorSet.add("Chris Evans");
		actorSet.add("Al Pacino");
		
		//1. println
//		System.out.println(actorSet);
		
		//2. foreach actor in actorSet
		for (String actor : actorSet) {
			System.out.println(actor);
		}
		
		//3. iterator
		System.out.println();
		for (Iterator iterator = actorSet.iterator(); iterator.hasNext();) {
			String actor = (String) iterator.next();
			System.out.println(actor);
			
		}
		
		//4. lambda expression
		System.out.println();
		actorSet.forEach((actor) -> {
			System.out.println(actor);
		});
		
		//5. simple for - array
		
		
		
	}

}
