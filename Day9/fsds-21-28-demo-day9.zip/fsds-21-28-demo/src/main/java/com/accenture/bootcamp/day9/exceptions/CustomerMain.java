package com.accenture.bootcamp.day9.exceptions;

public class CustomerMain {

	public static void main(String[] args) {
		
		Customers cust = new Customers();
		
		try {
			cust.findCustomer("1002");
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}

	}

}
