package com.accenture.bootcamp.day8.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.accenture.bootcamp.day6.Employee;

/*
 * List = ArrayList, LinkedList
 * 
 * Comparable = requires that you have access to the class file to be sorted
 */

public class ListDemo {

	public static void main(String[] args) {
	
		List<Employee> empList = new ArrayList<Employee>();
		
		empList.add(new Employee(100, "John Smith", 25));
		empList.add(new Employee(101, "Stella Jones", 35));
		empList.add(new Employee(301, "Mark Anthony", 29));
		empList.add(new Employee(206, "Agnes Williams", 40));
		empList.add(new Employee(125, "Ralph Rhodes", 45));
		empList.add(new Employee(101, "Stella Jones", 50));
		empList.add(new Employee(101, "Stella Jones", 27));
		empList.add(new Employee(101, "Stella Jones", 23));
		
		System.out.println("Before sorting...");
		empList.forEach( (employee) -> {
			System.out.println(employee);
		});
		
		//Collections.sort(empList);
		Collections.sort(empList, new EmployeeSorter());
		
		System.out.println("\nAfter sorting...");
		empList.forEach( (employee) -> {
			System.out.println(employee);
		});

	}

}
